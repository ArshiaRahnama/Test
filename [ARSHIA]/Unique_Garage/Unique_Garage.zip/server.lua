ESX = nil
HZ = Citizen

TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)

AddEventHandler('onResourceStart', function(resourceName)
	if (GetCurrentResourceName() ~= resourceName) then return end
	Wait(100)
	MySQL.Async.execute('UPDATE owned_vehicles SET stored = 1 WHERE stored = 0', {})
  end)

ESX.RegisterServerCallback("Unique_Garage:checkRepairCost", function(source, cb, fee)
	local xPlayer = ESX.GetPlayerFromId(source)
	if not xPlayer then
		cb(false)
		return
	end
	cb(xPlayer.canAfford(fee))
end)

-- Repair cost is now computed server-side from the vehicle's actual
-- engine/body health (via its network ID) instead of trusting a
-- client-sent price -- this is what the previous TODO here asked for.
-- The client only needs to send the vehicle's netId; a modified client
-- can no longer claim "price = 1" for a wrecked car since the price is
-- derived from real, server-read vehicle state.
local MAX_REPAIR_PRICE = 20000
local REPAIR_PRICE_PER_DAMAGE_POINT = 10 -- $ per point of (1000 - health), summed over engine+body

RegisterServerEvent("Unique_Garage:payhealth")
AddEventHandler("Unique_Garage:payhealth", function(netId)
	local xPlayer = ESX.GetPlayerFromId(source)
	if not xPlayer then return end

	local vehicle = NetworkGetEntityFromNetworkId(tonumber(netId) or 0)
	if not vehicle or vehicle == 0 or not DoesEntityExist(vehicle) then
		return
	end

	-- only the player currently driving the vehicle can pay to repair it
	if GetPedInVehicleSeat(vehicle, -1) ~= GetPlayerPed(source) then
		return
	end

	local engineDamage = math.max(0, 1000.0 - GetVehicleEngineHealth(vehicle))
	local bodyDamage = math.max(0, 1000.0 - GetVehicleBodyHealth(vehicle))
	local price = math.floor((engineDamage + bodyDamage) * REPAIR_PRICE_PER_DAMAGE_POINT / 100)
	price = math.min(price, MAX_REPAIR_PRICE)

	if price <= 0 then
		TriggerClientEvent("esx_ShowNotification", source, "Vehicle nyaz be tamir nadarad.")
		return
	end

	if not xPlayer.canAfford(price) then
		TriggerClientEvent("esx_ShowNotification", source, "Pool Kafi Nadarid.")
		return
	end

	xPlayer.payAny(price)
	SetVehicleFixed(vehicle)
	SetVehicleDeformationFixed(vehicle)
	SetVehicleEngineHealth(vehicle, 1000.0)
	SetVehicleBodyHealth(vehicle, 1000.0)
	TriggerClientEvent("esx_ShowNotification", source, _U("you_paid") .. price)
	TriggerEvent("esx_AddOnAccount:getSharedAccount", "society_mechanic", function(account)
		account.addMoney(price)
	end)
	TriggerEvent('DiscordBot:ToDiscord', 'amoney', 'AMoneyLog', '```css\n[ Player : '..GetPlayerName(source)..'(' .. source .. ') ]\n[ Player Steam : '..xPlayer.identifier..' ]\n[ Paid For : Vehicle Repair ]\n[ Amount : '..tostring(price)..' ]\n```', 'user', true, source, false)
end)

ESX.RegisterServerCallback('Unique_Garage:storeVehicle', function(source, cb, vehicleProps)
	local ownedCars = {}
	local vehplate = vehicleProps.plate:match("^%s*(.-)%s*$")
	local vehiclemodel = vehicleProps.model
	local xPlayer = ESX.GetPlayerFromId(source)

	MySQL.Async.fetchAll("SELECT * FROM owned_vehicles WHERE (owner = @player OR LOWER(`owner`) = @gang) AND plate = @plate", {
		["@player"] = xPlayer.identifier,
		["@gang"] = string.lower(xPlayer.gang.name),
		["@plate"] = vehicleProps.plate
	}, function (result)
		if result[1] ~= nil then
			local originalvehprops = json.decode(result[1].vehicle)
			if originalvehprops.model == vehiclemodel then
				MySQL.Async.execute("UPDATE owned_vehicles SET vehicle = @vehicle WHERE (owner = @player OR LOWER(`owner`) = @gang) AND plate = @plate", {
					["@player"] = xPlayer.identifier,
					["@gang"] = string.lower(xPlayer.gang.name),
					["@vehicle"] = json.encode(vehicleProps),
					["@plate"]  = vehicleProps.plate
				}, function (rowsChanged)
					if rowsChanged == 0 then

					end
					cb(true)
				end)
			else

				local xPlayers = ESX.GetPlayers()
				for i=1, #xPlayers, 1 do
					local xP = ESX.GetPlayerFromId(xPlayers[i])
					if tonumber(xP.permission_level) > 0 then
						TriggerClientEvent('esx_ChatMessage', xPlayers[i], "🚨 [HZ-AC] ", {255, 0, 0}, "^8"..GetPlayerName(source).."^2 ("..xPlayer.source..")^0 Tried to change vehicle hash ! ")
					end
				end

				cb(false)
			end
		else

			MySQL.Async.fetchAll("SELECT * FROM vehicle_keys WHERE (identifier = @player) AND plate = @plate", {
				["@player"] = xPlayer.identifier,
				["@plate"] = vehicleProps.plate
			}, function (result)

				if result[1] ~= nil then




					local trimmedKeyPlate = result[1].plate:match("^%s*(.-)%s*$")
					if trimmedKeyPlate == vehplate then
						MySQL.Async.execute("UPDATE owned_vehicles SET vehicle = @vehicle WHERE (owner = @player OR LOWER(`owner`) = @gang) AND plate = @plate", {
							["@player"] = xPlayer.identifier,
							["@gang"] = string.lower(xPlayer.gang.name),
							["@vehicle"] = json.encode(vehicleProps),
							["@plate"]  = vehicleProps.plate
						}, function (rowsChanged)
							if rowsChanged == 0 then

							end
							cb(true)
						end)
					else

						local xPlayers = ESX.GetPlayers()
						for i=1, #xPlayers, 1 do
							local xP = ESX.GetPlayerFromId(xPlayers[i])
							if tonumber(xP.permission_level) > 0 then
								TriggerClientEvent('esx_ChatMessage', xPlayers[i], "🚨 [HZ-AC] ", {255, 0, 0}, "^8"..GetPlayerName(source).."^2 ("..xPlayer.source..")^0 Tried to change vehicle hash ! ")
							end
						end

						cb(false)
					end
				else

					cb(false)
				end
			end)

		end
	end)
end)

ESX.RegisterServerCallback('GetVehicles', function(source, cb, job, playerjob, vehType)
	local Player = ESX.GetPlayerFromId(source)
	if job == 'Job' then
		-- organisation vehicles are ALWAYS available (never red / out / impounded).
		-- Government sees every vehicle of the organisation, members see their own.
		local gov = Player and Player.job and Player.job.name == 'government'
		local sql = gov and 'SELECT * FROM owned_vehicles WHERE job = ? AND type = ?' or 'SELECT * FROM owned_vehicles WHERE owner = ? AND job = ? AND type = ?'
		local args = gov and {playerjob, "car"} or {Player.identifier, playerjob, "car"}
		MySQL.Async.fetchAll(sql, args, function(result)
			if result[1] then
				for _, row in ipairs(result) do row.stored = 1 end
				cb(result)
			else
				cb(nil)
			end
		end)
	elseif job == 'Gang' then
		-- Gang-owned garage: vehicles stored under this gang, playerjob here is
		-- the gang name (mirrors how the 'Job' branch reuses playerjob for the job name).
		-- vehType lets FMGangs ask for 'car' / 'heli' / 'boat' separately, unlike the
		-- 'Job' branch above which is hardcoded to 'car'.
		MySQL.Async.fetchAll('SELECT * FROM owned_vehicles WHERE LOWER(`owner`) = ? AND type = ?', {string.lower(playerjob or ''), vehType or 'car'}, function(result)
			if result[1] then
				-- organisation fleet vehicles (job = 'job_fleet') are ALWAYS available:
				-- never red / out / impounded. Real gang vehicles keep their real state.
				for _, row in ipairs(result) do
					if row.job == 'job_fleet' then row.stored = 1 end
				end
				cb(result)
			else cb(nil) end
		end)
	elseif job == 'Impound' then
		if Player.gang.name == "nogang" then
			MySQL.Async.fetchAll('SELECT * FROM owned_vehicles WHERE owner = ? AND stored = ? AND type = ?', {Player.identifier, 2,"car"}, function(result)
				if result[1] then cb(result) else cb(nil) end
			end)
		else
			MySQL.Async.fetchAll('SELECT * FROM owned_vehicles WHERE (owner = @player OR LOWER(`owner`) = @gang) AND stored = @stored AND type = @Type', {
				['@player'] = Player.identifier,
				['@gang'] 	= string.lower(Player.gang.name),
				['@Type']   = 'car',
				['@stored'] = 2
			}, function(result)

				if result[1] then cb(result) else cb(nil) end
			end)
		end
	else
		MySQL.Async.fetchAll('SELECT * FROM owned_vehicles WHERE owner = ?', {Player.identifier}, function(result)
			if result[1] then cb(result) else cb(nil) end
		end)
	end
end)

RegisterNetEvent('Unique_Garage:saveProps', function(plate, props)
	MySQL.Async.execute('UPDATE owned_vehicles SET vehicle = ? WHERE plate = ?', {props, plate})
end)

RegisterNetEvent('SetVehState', function(stored, plate, table, job, playerjob)
	if job == 'Job' then
		if stored == 1 then
			MySQL.Async.execute('UPDATE owned_vehicles SET stored = ?, fuel = ?, engine = ?, body = ?, vehicle = ?, job = ? WHERE plate = ?', {stored, table.fuel, table.engine, table.body, json.encode(table.props), playerjob, plate})
		else
			MySQL.Async.execute('UPDATE owned_vehicles SET stored = ?, job = ? WHERE plate = ?', {stored, playerjob, plate})
		end
	elseif job == 'Gang' then
		-- same as 'Job' but keys off owner (gang name), never touches the job column
		if stored == 1 then
			MySQL.Async.execute('UPDATE owned_vehicles SET stored = ?, fuel = ?, engine = ?, body = ?, vehicle = ? WHERE LOWER(`owner`) = ? AND plate = ?', {stored, table.fuel, table.engine, table.body, json.encode(table.props), string.lower(playerjob or ''), plate})
		else
			MySQL.Async.execute('UPDATE owned_vehicles SET stored = ? WHERE LOWER(`owner`) = ? AND plate = ?', {stored, string.lower(playerjob or ''), plate})
		end
	else
		if stored == 1 then
			MySQL.Async.execute('UPDATE owned_vehicles SET stored = ?, fuel = ?, engine = ?, body = ?, vehicle = ?, job = ? WHERE plate = ?', {stored, table.fuel, table.engine, table.body, json.encode(table.props), '', plate})
		else
			MySQL.Async.execute('UPDATE owned_vehicles SET stored = ?, job = ? WHERE plate = ?', {stored, '', plate})
		end
	end
end)

RegisterNetEvent('SetVehState0', function(stored, plate)
	MySQL.Async.execute('UPDATE owned_vehicles SET stored = ? WHERE plate = ?', {stored, plate})
end)

ESX.RegisterServerCallback("IsVehOwned", function(source, cb, plate, job, playerjob)
	local Player = ESX.GetPlayerFromId(source)
	if job == 'Job' then
		MySQL.Async.fetchAll('SELECT * FROM owned_vehicles WHERE plate = ? AND owner = ? AND job = ?',{plate, Player.identifier, playerjob}, function(result)
			if result[1] then cb(true) else cb(false) end
		end)
	elseif job == 'Gang' then
		MySQL.Async.fetchAll('SELECT * FROM owned_vehicles WHERE plate = ? AND LOWER(`owner`) = ?', {plate, string.lower(playerjob or '')}, function(result)
			if result[1] then cb(true) else cb(false) end
		end)
	else
		MySQL.Async.fetchAll('SELECT * FROM owned_vehicles WHERE plate = ? AND owner = ?',{plate, Player.identifier}, function(result)
			if result[1] then cb(true) else cb(false) end
		end)
	end
end)

ESX.RegisterServerCallback("isPrice", function(source, cb, money)
	local Player = ESX.GetPlayerFromId(source)
	-- FIX: `Player` was used without a nil-check (crashes the callback with
	-- no cb() call -> NUI hangs forever with no feedback if the player
	-- object wasn't ready yet), and `money` was trusted as-is instead of
	-- being coerced/validated like the rest of this file already does for
	-- `Unique_Garage:payhealth`.
	if not Player then
		cb(false)
		return
	end
	money = tonumber(money) or 0
	if money < 0 then money = 0 end

	if Player.canAfford(money) then
		if money > 0 then Player.payAny(money) end
		TriggerEvent('DiscordBot:ToDiscord', 'amoney', 'AMoneyLog', '```css\n[ Player : '..GetPlayerName(source)..'(' .. source .. ') ]\n[ Player Steam : '..Player.identifier..' ]\n[ Paid For : Garage/Impound ]\n[ Amount : '..tostring(money)..' ]\n```', 'user', true, source, false)
		cb(true)
	else
		-- FIX: this used to fire 'esx_Notification:SendNotification', which
		-- nothing in this resource ever listened for, so the player never
		-- actually saw "You Don't Have Money" -- the SPAWN button just
		-- appeared to do nothing. Routed through the same SafeNotify path
		-- everything else in the resource uses.
		TriggerClientEvent("Unique_Garage:Notify", source, "~r~Shoma Pool Kafi Nadarid!")
		cb(false)
	end
end)

RegisterNetEvent('SetVehImpound', function(plate, body, engine, fuel)

	if IsVehicleOwned(plate) then
		MySQL.Async.fetchAll('UPDATE owned_vehicles SET stored = ?, body = ?, engine = ?, fuel = ? WHERE plate = ?',{2, body, engine, fuel, plate})
	end
end)

RegisterNetEvent('esx_advancedgarage:policeImpound', function(plate)
	if IsVehicleOwned(plate) then
		-- organisation (job) vehicles are never impounded: they stay available
		MySQL.Async.execute("UPDATE owned_vehicles SET stored = 2 WHERE plate = ? AND (job IS NULL OR job = '' OR job = 'civ')", {plate})
	end
end)

RegisterNetEvent('esx_advancedgarage:setVehicleState', function(plate, stored)
	if IsVehicleOwned(plate) then
		MySQL.Async.execute('UPDATE owned_vehicles SET stored = ? WHERE plate = ?', {stored and 1 or 0, plate})
	end
end)

function IsVehicleOwned(plate)
	local result = nil
	local prom = promise.new()
	MySQL.Async.fetchAll('SELECT plate FROM owned_vehicles WHERE plate = ?', {plate}, function(data)
		if data[1] then
			result = data[1]
			prom:resolve(result)
		else
			result = nil
			prom:resolve(result)
		end
	end)
	return Citizen.Await(prom)
end

