--[[ ===========================================================================
    Unique_inventory | config_joblock.lua

    قفل آیتم برای انبار جاب (Parzival:getJobINV2 / job2) - همون فلسفه‌ی
    "Item Access" گنگ: آیتم رو تو لیست نشون بده (حذفش نکن)، ولی اگه رتبه‌ی
    بازیکن کمتر از حداقلی باشه که اینجا تعریف شده، تو NUI روش قفل بیاد و
    سمت سرور هم (server/job_gang_lock.lua -> IsJobItemLocked) واقعاً بلاکش کن.

    برای سلاح‌های آرموری (job1) نیازی به این فایل نیست - همون سیستم موجود
    esx_society:getWeapons (تیک‌خورده تو باکس شغل رو پنل باس) استفاده میشه؛
    فقط به‌جای مخفی‌کردن سلاح غیرمجاز، الان نشونش میده و قفل می‌کنه
    (server/inventory_main.lua، getJobINV1).
=========================================================================== ]]

Config = Config or {}

-- Verbose [LOCKDBG] console logging for armory / job storage / gang chest / boss-action locks.
-- Set to false when you no longer need it.
Config.DebugLock = false

-- Config.JobStockMinGrade[jobName][itemName] = حداقل گریدی که برای برداشتن
-- این آیتم از انبار جاب (job2) لازمه. آیتمی که اینجا نیست = بدون محدودیت
-- (هر کسی که اصلاً دسترسی به انبار جاب رو داره می‌تونه برش داره).
Config.JobStockMinGrade = {
    police = {
        ['weaponcomponent_scope_large'] = 2,
        ['armour']                      = 1,
    },
    ambulance = {
        ['medikit'] = 1,
    },
}
