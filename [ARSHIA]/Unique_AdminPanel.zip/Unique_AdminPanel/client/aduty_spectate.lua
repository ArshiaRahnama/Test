ESX = nil
local spect2s = false
Citizen.CreateThread(function()
	while ESX == nil do
	TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
	Wait(1)
	end

	while true do
		if IsControlJustPressed(0, 243) then
			if LastPosition then
				ExecuteCommand('csp')
			elseif spect2s then
				TriggerEvent('Admin_Menu:spec')
			end
		end
		Wait(1)
	end
end)

RegisterNetEvent('Admin_Menu:SpectMenus')
AddEventHandler('Admin_Menu:SpectMenus', function(Cheks)
	spect2s = Cheks
end)

local InSpectatorMode	= false
local TargetSpectate	= nil
local LastPosition		= nil
local polarAngleDeg		= 0;
local azimuthAngleDeg	= 90;
local radius			= -3.5;
local cam 				= nil
local PlayerDate		= {}
local ShowInfos			= false
local group

function AdutyPolar3DToWorld3D(entityPosition, radius, polarAngleDeg, azimuthAngleDeg)

	local polarAngleRad   = polarAngleDeg   * math.pi / 180.0
	local azimuthAngleRad = azimuthAngleDeg * math.pi / 180.0

	local pos = {
		x = entityPosition.x + radius * (math.sin(azimuthAngleRad) * math.cos(polarAngleRad)),
		y = entityPosition.y - radius * (math.sin(azimuthAngleRad) * math.sin(polarAngleRad)),
		z = entityPosition.z - radius * math.cos(azimuthAngleRad)
	}

	return pos
end

function AdutySpectate(target)

	ESX.TriggerServerCallback('esx:getPlayerData', function(player)
		if not InSpectatorMode then
			LastPosition = GetEntityCoords(PlayerPedId())
		end

		local playerPed = PlayerPedId()

		SetEntityCollision(playerPed, false, false)
		SetEntityVisible(playerPed, false)
		SetEntityNoCollisionEntity(playerPed,  playerPed,  true)


		PlayerData = player
		if ShowInfos then
			SendNUIMessage({
				type = 'infos',
				data = PlayerData
			})
		end

		Citizen.CreateThread(function()

			if not DoesCamExist(cam) then
				cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
			end

			SetCamActive(cam, true)
			RenderScriptCams(true, false, 0, true, true)

			InSpectatorMode = true
			TargetSpectate  = target

		end)
	end, target)

end

function AdutyResetNormalCamera()
	InSpectatorMode = false
	TargetSpectate  = nil
	local playerPed = PlayerPedId()

	SetCamActive(cam,  false)
	RenderScriptCams(false, false, 0, true, true)

	SetEntityCollision(playerPed, true, true)
	SetEntityVisible(playerPed, true)
	TriggerServerEvent('esx_aduty:AntiCheatExempt', 5000, { teleport = true, speed = true, noclip = true })
	SetEntityCoords(playerPed, LastPosition.x, LastPosition.y, LastPosition.z)
	LastPosition = nil
end

function getPlayersList()

	local players = ESX.Game.GetPlayers()
	local data = {}

	for i=1, #players, 1 do

		local _data = {
			id = GetPlayerServerId(players[i]),
			name = GetPlayerName(players[i])
		}
		table.insert(data, _data)
	end

	return data
end

function OpenAdminActionMenu(player)

    ESX.TriggerServerCallback('esx_spectate:getOtherPlayerData', function(data)

      local jobLabel    = nil
      local sexLabel    = nil
      local sex         = nil
      local dobLabel    = nil
      local idLabel     = nil
	  local Money		= 0
	  local Bank		= 0
	  local Inventory	= nil

	  if data.job.grade_label ~= nil and  data.job.grade_label ~= '' then
    	jobLabel = 'Job : ' .. data.job.label .. ' - ' .. data.job.grade_label
      else
        jobLabel = 'Job : ' .. data.job.label
      end

	  if data.gang.grade_label ~= nil and  data.gang.grade_label ~= '' then
        GangLabel = 'Gang : ' .. data.gang.name .. ' - ' .. data.gang.grade_label.. ' | '.. data.gang.grade
      else
        GangLabel = 'Gang : ' .. data.gang.name
      end

	  print(data.sex)
      if data.sex ~= nil then
        if data.sex == 0 then
          sex = 'Male'
        else
          sex = 'Female'
        end
        sexLabel = 'Sex : ' .. sex
      else
        sexLabel = 'Sex : Unknown'
	  end

	  if data.dob ~= nil then
        dobLabel = 'DOB : ' .. data.dob
      else
        dobLabel = 'DOB : Unknown'
      end

	  if data.money ~= nil then
		Money = data.money
		else
		Money = 'No Data'
	  end

 	  if data.bank ~= nil then
		Bank = data.bank
		else
		Bank = 'No Data'
	  end

      if data.name ~= nil then
        idLabel = 'Steam ID : ' .. GetPlayerName(player)
      else
        idLabel = 'Steam ID : Unknown'
      end

      local elements = {
        {label = 'Name: ' .. string.gsub(data.name, "_", " "), value = nil},
        {label = 'Money: '.. data.money, value = nil},
        {label = 'Bank: '.. data.bank, value = nil},
		{label = jobLabel,    value = nil},
		{label = GangLabel,    value = nil},
        {label = idLabel,     value = nil},
    }

    table.insert(elements, {label = '--- Inventory ---', value = nil})

    for i=1, #data.inventory, 1 do
      if data.inventory[i].count > 0 then
        table.insert(elements, {
          label          = data.inventory[i].label .. ' x ' .. data.inventory[i].count,
          value          = nil,
          itemType       = 'item_standard',
          amount         = data.inventory[i].count,
        })
      end
    end

    table.insert(elements, {label = '--- Weapons ---', value = nil})

    for i=1, #data.weapons, 1 do
      table.insert(elements, {
        label          = ESX.GetWeaponLabel(data.weapons[i].name),
        value          = nil,
        itemType       = 'item_weapon',
        amount         = data.ammo,
      })
    end
      if data.licenses ~= nil then

        table.insert(elements, {label = '--- Licenses ---', value = nil})

        for i=1, #data.licenses, 1 do
          table.insert(elements, {label = data.licenses[i].label, value = nil})
        end

      end

      ESX.UI.Menu.Open(
        'default', GetCurrentResourceName(), 'citizen_interaction',
        {
          title    = 'Player Control',
          align    = 'top-left',
          elements = elements,
        },
        function(data, menu)

        end,
        function(data, menu)
          menu.close()
        end
      )

    end, GetPlayerServerId(player))
end

RegisterNetEvent('es_admin:setGroup')
AddEventHandler('es_admin:setGroup', function(g)
	print('group setted ' .. g)
	group = g
end)

RegisterNetEvent('esx_spectate:spectatexxxx')
AddEventHandler('esx_spectate:spectatexxxx', function(targ)
AdutySpectate(targ)
end)

RegisterNetEvent('esx_spectate:spectateclose')
AddEventHandler('esx_spectate:spectateclose', function(targ)
AdutyResetNormalCamera()
end)

RegisterNetEvent('esx_spectate:AdutySpectate')
AddEventHandler('esx_spectate:AdutySpectate', function()

	SetNuiFocus(true, true)

	SendNUIMessage({
		type = 'show',
		data = getPlayersList(),
		player = GetPlayerServerId(PlayerId())
	})

end)

RegisterNUICallback('select', function(data, cb)
	print("select UI " .. json.encode(data))
	AdutySpectate(data.id)
	SetNuiFocus(false)
end)

RegisterNUICallback('close', function(data, cb)
	print("closing UI")
	SetNuiFocus(false)
end)

RegisterNUICallback('quit', function(data, cb)
	SetNuiFocus(false)
	AdutyResetNormalCamera()
end)

RegisterNUICallback('kick', function(data, cb)
	SetNuiFocus(false)
	TriggerServerEvent('esx_spectate:kick', data.id, data.reason)
	TriggerEvent('esx_spectate:AdutySpectate')
end)

Citizen.CreateThread(function()

  	while true do

		Wait(10)

		if InSpectatorMode then

			local targetPlayerId = GetPlayerFromServerId(TargetSpectate)
			local playerPed	  = PlayerPedId()
			local targetPed	  = GetPlayerPed(targetPlayerId)
			local coords	 = GetEntityCoords(targetPed)

			for i=0, 255, 1 do
				if i ~= PlayerId() then
					local otherPlayerPed = GetPlayerPed(i)
					SetEntityNoCollisionEntity(playerPed,  targetPed,  true)
					SetEntityVisible(playerPed, false)
					SetEntityCollision(playerPed, false, false)
				end
			end

			if IsControlPressed(2, 241) then
				radius = radius + 2.0;
			end

			if IsControlPressed(2, 242) then
				radius = radius - 2.0;
			end

			if radius > -1 then
				radius = -1
			end

			local xMagnitude = GetDisabledControlNormal(0, 1);
			local yMagnitude = GetDisabledControlNormal(0, 2);

			polarAngleDeg = polarAngleDeg + xMagnitude * 10;

			if polarAngleDeg >= 360 then
				polarAngleDeg = 0
			end

			azimuthAngleDeg = azimuthAngleDeg + yMagnitude * 10;

			if azimuthAngleDeg >= 360 then
				azimuthAngleDeg = 0;
			end

			local nextCamLocation = AdutyPolar3DToWorld3D(coords, radius, polarAngleDeg, azimuthAngleDeg)

			SetCamCoord(cam,  nextCamLocation.x,  nextCamLocation.y,  nextCamLocation.z)
			PointCamAtEntity(cam,  targetPed)
			TriggerServerEvent('esx_aduty:AntiCheatExempt', 5000, { teleport = true, speed = true, noclip = true })
			SetEntityCoords(playerPed,  coords.x, coords.y, coords.z + 50)

			if IsControlJustReleased(2, 73) then
			OpenAdminActionMenu(targetPlayerId)
			end


			local text = {}


			local targetGod = GetPlayerInvincible(targetPlayerId)
			local vehicle =  GetVehiclePedIsIn(targetPed, false )
			if targetGod then
				table.insert(text,"Godmode: ~r~Found~w~")
			else
				table.insert(text,"Godmode: ~g~Not Found~w~")
			end
			if not CanPedRagdoll(targetPed) and not IsPedInAnyVehicle(targetPed, false) and (GetPedParachuteState(targetPed) == -1 or GetPedParachuteState(targetPed) == 0) and not IsPedInParachuteFreeFall(targetPed) then
				table.insert(text,"~r~Anti-Ragdoll~w~")
			end

			table.insert(text,"Health"..": "..(GetEntityHealth(targetPed)-100).."/".. 200-100)
			table.insert(text,"Armor : "..GetPedArmour(targetPed).."/100")
			if vehicle ~= 0 then
				table.insert(text,"Vehicle Engine : "..GetVehicleEngineHealth(vehicle).."/1000.0")
			end

			for i,theText in pairs(text) do
				SetTextFont(0)
				SetTextProportional(1)
				SetTextScale(0.0, 0.30)
				SetTextDropshadow(0, 0, 0, 0, 255)
				SetTextEdge(1, 0, 0, 0, 255)
				SetTextDropShadow()
				SetTextOutline()
				SetTextEntry("STRING")
				AddTextComponentString(theText)
				EndTextCommandDisplayText(0.3, 0.7+(i/30))
			end
		end
  	end
end)
